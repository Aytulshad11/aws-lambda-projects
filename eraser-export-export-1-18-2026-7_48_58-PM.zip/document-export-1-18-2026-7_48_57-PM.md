# AWS CSV Processing Pipeline Architecture



